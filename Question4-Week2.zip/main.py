def main():
  make = input("Enter the make of the auto: ")
  model = input("Enter the model of the auto: ")
  msrp = float(input("Enter the MSRP amount: "))
  discount_percent = float(input("Enter the discount percent (as a decimal, e.g., 0.20 for 20%): "))
  amount_off = msrp * discount_percent
  discounted_price = msrp - amount_off
  print("\nAuto Purchase Details:")
  print(f"Make: {make}")
  print(f"Model: {model}")
  print(f"MSRP: ${msrp:.2f}")
  print(f"Discount Percent: {discount_percent * 100:.2f}%")
  print(f"Amount Off: ${amount_off:.2f}")
  print(f"Discounted Price: ${discounted_price:.2f}")
if __name__ == "__main__":
  main()

