# Function to read data from file and process it
def process_orders(filename):
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()

        # Initialize variables
        items = []
        quantities = []
        prices = []

        # Process lines
        for i in range(0, len(lines), 3):
            item = lines[i].strip()
            quantity = int(lines[i+1].strip())
            price = float(lines[i+2].strip())

            items.append(item)
            quantities.append(quantity)
            prices.append(price)

        # Calculate extended prices and other metrics
        extended_prices = [quantities[i] * prices[i] for i in range(len(items))]
        total_extended_price = sum(extended_prices)
        order_count = len(items)
        average_order = total_extended_price / order_count if order_count != 0 else 0

        # Display results
        for i in range(len(items)):
            print(f"Item: {items[i]}, Quantity: {quantities[i]}, Price: {prices[i]}, Extended Price: {extended_prices[i]}")

        print(f"\nTotal Extended Price: {total_extended_price}")
        print(f"Number of Orders: {order_count}")
        print(f"Average Order Value: {average_order}")

    except FileNotFoundError:
        print("The file was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# File name
filename = 'items.txt'

# Process the orders
process_orders(filename)

