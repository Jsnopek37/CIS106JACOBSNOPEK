def calculate_bonus(salary):
    if salary >= 100000:
        return salary * 0.20
    elif salary >= 50000:
        return salary * 0.15
    else:
        return salary * 0.10

def main():
    # Open and read the data from the text file
    with open('employee_data.txt', 'r') as file:
        lines = file.readlines()

    employees = []
    for i in range(0, len(lines), 2):
        last_name = lines[i].strip()
        salary = float(lines[i+1].strip())
        employees.append((last_name, salary))

    # Calculate bonuses and print the results
    total_bonus = 0
    print(f"{'Last Name':<15}{'Salary':<15}{'Bonus':<15}")
    for last_name, salary in employees:
        bonus = calculate_bonus(salary)
        total_bonus += bonus
        print(f"{last_name:<15}{salary:<15.2f}{bonus:<15.2f}")

    # Print the total bonuses paid out
    print(f"\nTotal bonuses paid out: ${total_bonus:.2f}")

if __name__ == "__main__":
    main()
