
COST_PER_CREDIT_IN_DISTRICT = 250.00
COST_PER_CREDIT_OUT_OF_DISTRICT = 500.00
total_tuition = 0.0
student_count = 0
with open('students.txt', 'r') as file:
    lines = file.readlines()

    for line in lines:

        last_name, district_code, credits_taken = line.strip().split(',')


        credits_taken = int(credits_taken)


        if district_code == 'I':
            cost_per_credit = COST_PER_CREDIT_IN_DISTRICT
        elif district_code == 'O':
            cost_per_credit = COST_PER_CREDIT_OUT_OF_DISTRICT
        else:
            
            print(f"Error: Unknown district code '{district_code}' for student {last_name}")
            continue

        
        tuition_owed = credits_taken * cost_per_credit

        
        total_tuition += tuition_owed
        student_count += 1

        
        print(f"{last_name}, {credits_taken} credits, Tuition Owed: ${tuition_owed:.2f}")
print("\nSummary:")
print(f"Total Tuition Owed: ${total_tuition:.2f}")
print(f"Number of Students: {student_count}")
