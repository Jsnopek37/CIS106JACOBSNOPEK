def calculate_ticket_cost(number_of_tickets):
  if number_of_tickets >= 25:
      price_per_ticket = 50
  elif number_of_tickets >= 10:
      price_per_ticket = 60
  elif number_of_tickets >= 5:
      price_per_ticket = 70
  else:
      price_per_ticket = 75
  total_cost = number_of_tickets * price_per_ticket
  print(f"Number of Tickets: {number_of_tickets}")
  print(f"Price per Ticket: ${price_per_ticket:.2f}")
  print(f"Total Cost: ${total_cost:.2f}")
number_of_tickets = int(input("Enter the number of concert tickets: "))
calculate_ticket_cost(number_of_tickets)

