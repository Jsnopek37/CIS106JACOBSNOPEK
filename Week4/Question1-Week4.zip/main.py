def calculate_widget_price(quantity):
  if quantity > 10000:
      price_per_widget = 10
  elif quantity >= 5000:
      price_per_widget = 20
  else:
      price_per_widget = 30
  extended_price = quantity * price_per_widget
  tax_amount = extended_price * 0.07
  total_amount = extended_price + tax_amount
  print(f"Extended Price: ${extended_price:.2f}")
  print(f"Tax Amount: ${tax_amount:.2f}")
  print(f"Total Amount: ${total_amount:.2f}")
quantity = int(input("Enter the quantity of widgets: "))
calculate_widget_price(quantity)
