def main():
  pi = 3.174
  radius = float(input("Enter the radius of the circle: "))
  area = pi * radius * radius
  perimeter = 2 * pi * radius
  print("\nCircle Details:")
  print(f"Radius: {radius}")
  print(f"Area: {area:.2f}")
  print(f"Perimeter: {perimeter:.2f}")
if __name__ == "__main__":
  main()
